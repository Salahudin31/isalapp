<?php
class General
{
	function logged_in(){
		return(isset($_SESSION['loginid']))? true : false;
	}
	function logged_in_protect(){
		if($this->logged_in() === true){
			header('Location: index1.php');
			exit();
		}
	}
	public function logged_out_protect() {
		if ($this->logged_in() === false) {
			header('Location: index.php');
			exit();
		}
	}
}
?>