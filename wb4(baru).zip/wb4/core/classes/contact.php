<?php
Class Contact {
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function contact_exists($id){
		$query = $this->db->prepare("SELECT COUNT(`id`) FROM `contact` WHERE `id` = ?");
		$query->bindValue(1,$id);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage()); 
		}
	}
	function daftar_contactId($bahasa){
		$query = $this->db->prepare("SELECT * FROM `bahasa` = ?");
		$query->bindValue(2,$semester_id);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage());
		}
	}
	function add_contact($id,$nim,$nama_mahasiswa,$nama_skill,$nama_bahasa){
		$query = $this->db->prepare("INSERT INTO `contact` (`id`,`nim`,`nama_mahasiswa`,`nama_skill`,`nama_bahasa`) VALUES (?,?,?,?,?)");
		$query->bindValue(1,$id);
		$query->bindValue(2,$nim);
		$query->bindValue(3,$nama_mahasiswa);
		$query->bindValue(4,$nama_skill);
		$query->bindValue(5,$nama_bahasa);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_contact($id,$nim,$nama_mahasiswa,$nama_skill,$nama_bahasa){
		$query = $this->db->prepare("UPDATE `contact` SET `nim` = ? , `nama_mahasiswa` = ? , `nama_skill` = ? , `nama_bahasa` = ? WHERE `id` = ?");
		$query->bindValue(5,$id);
		$query->bindValue(1,$nim);
		$query->bindValue(2,$nama_mahasiswa);
		$query->bindValue(3,$nama_skill);
		$query->bindValue(4,$nama_bahasa);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($id){
		$sql="DELETE FROM `contact` WHERE `id` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function contact_data($id){
		$query = $this->db->prepare("SELECT * FROM `contact` WHERE `id`= ?");
		$query->bindValue(1, $id);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_contact(){
		$query = $this->db->prepare("SELECT * FROM `contact`");
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
		return $query->fetchAll();
	}
}
?>