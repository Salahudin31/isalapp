<?php
class Tbl_Image
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	#buat grup image di awal
	function add_grup_image($id_table,$nama_table,$date_table,$nama_foto){
		$query = $this->db->prepare("INSERT INTO `tbl_image` (`id_table`,`nama_table`,`nama_foto`,`date_table`) VALUES (?,?,?,?)");
		$query->bindValue(1,$id_table);
		$query->bindValue(2,$nama_table);
		$query->bindValue(3,$nama_foto);
		$query->bindValue(4,$date_table);
		try{
			$query->execute();			
		}catch(PDOException $e){
			die($e->getMessage());
		}

	}
	#buat nama contact
	function add_contact_image($id_table,$file_foto,$date_table,$nama_mahasiswa){
		$query = $this->db->prepare("INSERT INTO `tbl_image` (`id_table`,`file_foto`,`date_table`,`nama_mahasiswa`) VALUES (?,?,?)");
		$query->bindValue(1,$id_table);
		$query->bindValue(2,$file_foto);
		$query->bindValue(3,$date_table);
		$query->bindValue(3,$nama_mahasiswa);
		try{
			$query->execute();			
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	#ganti foto contact
	function update_contact_image($nama_mahasiswa,$file_foto,$date_table){
		$query = $this->db->prepare("UPDATE `tbl_image` SET `file_foto` = ? , `date_table` = ? WHERE `nama_mahasiswa` = ?");
		$query->bindValue(1,$file_foto);
		$query->bindValue(2,$date_table);
		$query->bindValue(3,$nama_mahasiswa);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	#delete grup foto
	function delete($nama_table){
		$sql="DELETE FROM `tbl_image` WHERE `nama_table` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $nama_table);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	#delete foto di grup foto
	function deletefoto($nama_foto){
		$sql="DELETE FROM `tbl_image` WHERE `nama_foto` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $nama_foto);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	#cari nama grup foto
	function tbl_image_data($nama_table){
		$query = $this->db->prepare("SELECT * FROM `tbl_image` WHERE `nama_table`= ?");
		$query->bindValue(1, $nama_table);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_tbl_image(){
		$query = $this->db->prepare("SELECT * FROM `tbl_image` ORDER BY `date_table` ASC");
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
		return $query->fetchAll();
	}
	function get_imageProfil($nama_mahasiswa){
		$query = $this->db->prepare("SELECT * FROM `tbl_image` WHERE `nama_mahasiswa`= ?");
		$query->bindValue(1,$nama_mahasiswa);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>