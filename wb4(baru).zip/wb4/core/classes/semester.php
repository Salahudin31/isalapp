<?php
class Semester
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function daftar_semester($semester){
		$query = $this->db->prepare("SELECT COUNT(`semester_id`) FROM `semester`= ?");
		$query->bindValue(1,$semester);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage()); 
		}
	}
	function daftar_semesterSemester($semester_id){
		$query = $this->db->prepare("SELECT COUNT(`semester_id`) FROM `semester_id`= ?");
		$query->bindValue(2,$semester_id);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage());
		}
	}
	function add_semester($semester_id,$semester,$huruf_semester){
		$query = $this->db->prepare("INSERT INTO `semester` (`semester_id`,`semester`,`hruf_semester`) VALUES (?,?)");
		$query->bindValue(1,$semester_id);
		$query->bindValue(2,$semester);
		$query->bindValue(3,$huruf_semester);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_semester($semester_id,$semester,$huruf_semester){
		$query = $this->db->prepare("UPDATE `semester` SET `semester` = ? , `hruf_semester` = ? WHERE `semester_id` = ?");
		$query->bindValue(2,$semester_id);
		$query->bindValue(3,$huruf_semester);
		$query->bindValue(1,$semester);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($semester_id){
		$sql="DELETE FROM `semester` WHERE `semester_id` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $semester_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function semester_data($semester_id){
		$query = $this->db->prepare("SELECT * FROM `semester` WHERE `semester_id`= ?");
		$query->bindValue(1, $semester_id);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_semester(){
		$query = $this->db->prepare("SELECT * FROM `semester` ORDER BY `semester_id` ASC");
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
		return $query->fetchAll();
	}
	function get_semesterdata(){
		$query = $this->db->prepare("SELECT * FROM `semester`");
		try{
			$query->execute();
			
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>