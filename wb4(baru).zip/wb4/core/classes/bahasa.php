<?php
Class Bahasa {
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function add_bahasa($id_bahasa,$nama_bahasa){
		$query = $this->db->prepare("INSERT INTO `bahasa` (`id_bahasa`,`nama_bahasa`) VALUES (?,?)");
		$query->bindValue(1,$id_bahasa);
		$query->bindValue(2,$nama_bahasa);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_bahasa($id_bahasa,$nama_bahasa){
		$query = $this->db->prepare("UPDATE `bahasa` SET `nama_bahasa` = ? WHERE `id_bahasa` = ?");
		$query->bindValue(2,$id_bahasa);
		$query->bindValue(1,$nama_bahasa);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($id_bahasa){
		$sql="DELETE FROM `bahasa` WHERE `id_bahasa` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $id_bahasa);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function bahasa_data($id_bahasa){
		$query = $this->db->prepare("SELECT * FROM `bahasa` WHERE `id_bahasa`= ?");
		$query->bindValue(1, $id_bahasa);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_bahasa(){
		$query = $this->db->prepare("SELECT * FROM `bahasa` ORDER BY `nama_bahasa` ASC");
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>