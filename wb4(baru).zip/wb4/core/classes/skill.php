<?php
Class Skill{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function add_skill($id_skill,$nama_skill,$nilai_skill){
		$query = $this->db->prepare("INSERT INTO `skill` (`id_skill`,`nama_skill`,`nilai_skill`) VALUES (?,?)");
		$query->bindValue(1,$id_skill);
		$query->bindValue(2,$nama_skill);
		$query->bindValue(2,$nilai_skill);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_skill($id_skill,$nama_skill,$nilai_skill){
		$query = $this->db->prepare("UPDATE `skill` SET `nama_skill` = ? , `nilai_skill` = ? WHERE `id_skill` = ?");
		$query->bindValue(2,$id_skill);
		$query->bindValue(1,$nama_skill);
		$query->bindValue(1,$nilai_skill);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($id_skill){
		$sql="DELETE FROM `skill` WHERE `id_skill` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $id_skill);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function skill_data($id_skill){
		$query = $this->db->prepare("SELECT * FROM `skill` WHERE `id_skill`= ?");
		$query->bindValue(1, $id_skill);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_skill(){
		$query = $this->db->prepare("SELECT * FROM `skill` ORDER BY `nama_skill` ASC");
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>