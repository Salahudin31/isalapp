<?php
/**
* 
*/
class MataKuliah
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function daftar_mataKuliah($nama_matkul){
		$query = $this->db->prepare("SELECT COUNT(`matkul_kd`) FROM `matakuliah`= ?");
		$query->bindValue(1,$nama_matkul);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage()); 
		}
	}
	function daftar_mataKuliahSemester($semester_id){
		$query = $this->db->prepare("SELECT COUNT(`matkul_kd`) FROM `semester_id`= ?");
		$query->bindValue(2,$semester_id);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage());
		}
	}
	function add_mataKuliah($matkul_kd,$nama_matkul,$semester_id){
		$query = $this->db->prepare("INSERT INTO `matakuliah` (`matkul_kd`,`nama_matkul`,`semester_id`) VALUES (?,?,?)");
		$query->bindValue(1,$matkul_kd);
		$query->bindValue(2,$nama_matkul);
		$query->bindValue(3,$semester_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_mataKuliah($matkul_kd,$nama_matkul,$semester_id){
		$query = $this->db->prepare("UPDATE `matakuliah` SET `nama_matkul` = ? , `semester_id` = ? WHERE `matkul_kd` = ?");
		$query->bindValue(3,$matkul_kd);
		$query->bindValue(1,$nama_matkul);
		$query->bindValue(2,$semester_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($matkul_kd){
		$sql="DELETE FROM `matakuliah` WHERE `matkul_kd` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $matkul_kd);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function mataKuliah_data($matkul_kd){
		$query = $this->db->prepare("SELECT * FROM `matakuliah` WHERE `matkul_kd`= ?");
		$query->bindValue(1, $matkul_kd);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function mataKuliah_semester($semester){
		$query = $this->db->prepare("SELECT * FROM `matakuliah` WHERE `semester_id`= ?");
		$query->bindValue(1, $semester);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
		return $query->fetchAll();
	}
	function get_mataKuliah(){
		$query = $this->db->prepare("SELECT * FROM `matakuliah` ORDER BY `semester_id` ASC");
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
		return $query->fetchAll();
	}
}
?>