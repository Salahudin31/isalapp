<?php 
ob_start(); // Added to avoid a common error of 'header already sent'
session_start();
require_once 'connect/dbconfig.php';
require_once 'classes/general.php';
require_once 'classes/user.php';
require_once 'classes/news.php';
require_once 'classes/semester.php';
require_once 'classes/tbl_image.php';
require_once 'classes/matakuliah.php';
require_once 'classes/artikel.php';

$general 	= new General();
$users 		= new User($db);
$semester 	= new Semester($db);
$news 		= new News($db);
$tbl_image 	= new Tbl_Image($db);
$matakuliah	= new MataKuliah($db);
$artikel	= new Artikel($db);
$skill		= new Skill($db);
$bahasa		= new Bahasa($db);
$contacts	= new Contact($db);


$errors = array();
?>