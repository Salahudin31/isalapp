<?php 
ob_start(); // Added to avoid a common error of 'header already sent'
session_start();
require_once 'connect/dbconfig.php';
function my_autoload($class)
{   $filename = 'classes/'.$class.'.php';
	include_once $filename;
}
spl_autoload_register('my_autoload');
try {
	$general 		= new General();
	$user 			= new User($db);
	$semester 		= new Semester($db);
	$news 			= new News($db);
	$artikel 		= new Artikel($db);
	$tbl_image		= new Tbl_Image($db);
	$matakuliah		= new MataKuliah($db);
	$skill			= new Skill($db);
	$bahasa			= new Bahasa($db);
	$contacts		= new Contact($db);

} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}
?>