  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>

<div class="w3-row-padding ">

<div class="w3-twothird">
  <br>
  <img src="assets/image/b4-recipe.png" class="w3-round" style="width:50%">
  <h2>Informasi</h2>
  <table class="w3-table w3-striped w3-bordered w3-border">
  <thead class="w3-teal"><th style="width:30%">Title</th><th>Keterangan</th></thead>
  <tr><td style="width:30%">Nama</td><td>TI.15.B.4</td></tr>
  <tr><td>Fakultas</td><td>Teknik</td></tr>
  <tr><td>Jurusan</td><td>Teknik Informatika</td></tr>
  <tr><td>Universitas/Kampus</td><td>Pelita Bangsa</td></tr>
  </table>
  <h2>Semester</h2>
  <table class="w3-table w3-striped w3-bordered w3-border">
  <thead class="w3-teal"><th style="width:30%">Nama</th><th>Nilai Semester</th></thead>
  <?php 
  require 'core/import.php';
  $semesters = $semester->get_semester(); 
      foreach ($semesters as $data_semester) {
        echo "<tr><td>".$data_semester['hruf_semester']."</td><td>".$data_semester['semester']."</td></tr>";
      }
  ?>
  </table>
</div>

<div class="w3-third">
  <h1>TI.15.B.4</h1>
  <p>TI.15.B.4 atau disingkat B4 adalah salah satu kelas diperguruan tinggi di <em>Pelita Bangsa</em>.</p>
  <p>B4 disini terbentuk atau bisa dibilang lahir di tahun 2015 dengan jumlah 43 mahasiswa</p>
  <p>bla bla bla</p>
  <p>The flavors varies from noticeable acidity (Cold Climates), to crisply and mineral (Chablis, France) 
  with flavors of green plum, apple and pear, to heavy oak and tropical fruit flavors (the New World). </p>
  <p>In cooler climates Chardonnay tends to be under-riped. </p>
  <p>In warmer climates the flavors tend to vary from lemon to peach and melon.</p>
  <p>In very warm climates Chardonnay tends to be over-riped.</p>
  <p>Oaked Chardonnay tends to have softer acidity and more fruit flavors with 
  added butter, cream and hazelnut notes.</p>
 </div>

</div><br>