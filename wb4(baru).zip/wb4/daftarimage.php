  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
  <link rel="stylesheet" href="assets/w3/font-awesome.min.css"> 

<style type="text/css">
div.w3-row {
	margin: auto;
}
	img.image {
		margin: 1%;
		width: 30.9%;
		height: 13%;
	}

</style>
  <div class="w3-container">
  	<h4>Gunung Gede</h4>
  	<div class="w3-row">
  		<img class="image" src="assets/image/abraao_segundo_monster_green_hair_chains_irons_discharge_94534_1366x768.jpg" alt="">
  		<img class="image" src="assets/image/cloudscape_5-wallpaper-1366x768.jpg" alt="">
  		<img class="image" src="assets/image/cube_burst_forming_68435_1366x768.jpg" alt="">
  		<img class="image" src="assets/image/images.jpg" alt="">
  		<img class="image" src="assets/image/light_the_fire-wallpaper-1366x768.jpg" alt="">
  		<img class="image" src="assets/image/lighthouse_ship-wallpaper-1366x768.jpg" alt="">
  		<img class="image" src="assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg" alt="">
  		<img class="image" src="assets/image/nature_art-wallpaper-1366x768.jpg" alt="">
  		<img class="image" src="assets/image/pp.jpg" alt="">
  		<img class="image" src="assets/image/ps.jpg" alt="">
  		<img class="image" src="assets/image/colored_pencil-wallpaper-1366x768.jpg" alt="">
  	</div>
  </div>