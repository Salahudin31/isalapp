<?php

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DBNAME","b4");
define("NPAGE","25");

?>