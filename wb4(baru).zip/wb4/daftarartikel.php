 <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
<div class="w3-container">
<?php
  require 'core/import.php';

  $id_matkul = $_GET['id'];
  $artikels = $artikel->get_matkul_artikel($id_matkul);

  foreach ($artikels as $data_artikel) {
    echo "
           <div class='w3-third' style='width: 100%'>
            <a href='detailartikel.php?kode=".$data_artikel['file_artikel']."'><div class='w3-card-4' style='margin: 2%;'>
              <img src='assets/file/".$data_artikel['file_artikel']."' style='width:100%; height: 200px'>
              <div class='w3-container'>
                <h4>".$data_artikel['nama_artikel']."</h4>
              </div>
            </div></a>
          </div>";
  }
?>
</div>