  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
<style type="text/css">
	p{
		margin-left: 2%;
	}
	img {
		width: 88%;
		height: 25%;
		margin: 5%;
	}
</style>
  <div class="w3-container">
  	<div class="w3-row">
  	<img class="w3-round" src="assets/image/colored_pencil-wallpaper-1366x768.jpg">
  	<div class="">
  		<p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non congue ullam corper. Praesent tincidunt sed tellus ut rutrum.</p>
  		<p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non congue ullam corper. Praesent tincidunt sed tellus ut rutrum.</p>
  		<p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non congue ullam corper. Praesent tincidunt sed tellus ut rutrum.</p>
  		<p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non congue ullam corper. Praesent tincidunt sed tellus ut rutrum.</p>
  	</div>
  	</div>
  </div>