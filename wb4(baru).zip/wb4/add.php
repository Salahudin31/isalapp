<!doctype html>
<html lang="en">
<?php
  include_once 'db.php';

  if(isset($_POST['tambah'])){

    $nim = $_POST['tnim'];
    $nama = $_POST['tnama'];
    $email = $_POST['temail'];
    $telp = $_POST['ttelp'];
    $alamat = $_POST['talamat'];
  $dbKoneksi = new db('mahasiswa');
  $dbKoneksi->open();
  $dbKoneksi->save(array('nim'=>$nim,'nama'=>$nama,'email'=>$email,'telp'=>$telp,'alamat'=>$alamat));

}

?>
  <head>
    <title>Data Mahasiswa</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css" >
  </head>
  <body>
  <div class="container">
        <h1>Tambah Data Mahasiswa</h1>

        <form action="../B4/add.php" method="POST">
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">NIM</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="tnim" placeholder="NIM">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Nama Mahasiswa</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="tnama" placeholder="Nama Mahasiswa">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Email</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="temail" placeholder="Email">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Telepon</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="ttelp" placeholder="Telepon">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Alamat</label>
            <div class="col-sm-9">
              <textarea class="form-control" name="talamat" placeholder="Alamat"></textarea> 
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-12">
              <input type="submit" class="btn btn-primary btn-lg btn-block" name="tambah" value="save">
            </div>
          </div>
        </form>  
  </div>
 </body>
</html>  