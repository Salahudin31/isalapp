<?php

function viewcontact(){
  require './core/import.php';
  $detpro = 'detailcontact.php';
  
$general->logged_out_protect();

  $contacts = $contacts->get_contact();
  $contacts_count = count($contacts);
  echo $contacts_count;
  foreach ($contacts as $contact) {
  $tbl_images = $tbl_image->get_imageProfil($contact['nama_mahasiswa']);
    echo "<ul class=w3-ul w3-card-4>
    <a href='././$detpro?id=".$contact['id']."'  target='target_Iframe'><li class='w3-padding-16'>
      <img src=./assets/image/".$tbl_images['file_foto']." class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>".$contact['nama_mahasiswa']."</span><br>
      <span>Web Designer</span>
    </li></a>";  
  }
}
function viewdetpro(){
  
    echo "<iframe src='home.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
}
?>