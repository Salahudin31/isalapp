<?php
function listnew(){
	$listnew = 'listnew.php';
	echo "<div class='w3-container'>
<hr width='100%' size='1'>
<h4 class='title'>Kiriman Terbaru</h4>
<div class='w3-card-4 w3-margin'>
  <img src='assets/image/colored_pencil-wallpaper-1366x768.jpg' alt='Nature' width='800' height='250' style='margin-top: 2%; margin-left: 9px;'>
  <div class='w3-container w3-padding-8'>
    <h3><b>TITLE HEADING</b></h3>
    <h5>Title description
    <span class='w3-opacity'>April 7, 2014</span></h5>
  </div>
  <div class='w3-container'>
    <p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non congue ullam corper. Praesent tincidunt sed tellus ut rutrum. </p>
    <a href='detailsnew.php'>baca ..</a>
  </div>
</div>
<div class='w3-card-4 w3-margin'>
  <img src='assets/image/colored_pencil-wallpaper-1366x768.jpg' alt='Nature' width='800' height='250' style='margin-top: 2%; margin-left: 9px;'>
  <div class='w3-container w3-padding-8'>
    <h3><b>TITLE HEADING</b></h3>
    <h5>Title description
    <span class='w3-opacity'>April 7, 2014</span></h5>
  </div>
  <div class='w3-container'>
    <p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non congue ullam corper. Praesent tincidunt sed tellus ut rutrum. </p>
    <a href='detailsnew.php'>baca ..</a>
  </div>
</div>
</div>
";
}
function viewdetnew(){
	if(isset($_GET['listnew'])){
    $listnew = $_GET['listnew'];

    echo "<iframe src='listdetailnew.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
?>