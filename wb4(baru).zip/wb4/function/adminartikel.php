
<form class="w3-container w3-card-4"><br><p><label class="w3-text-grey">Nama Artikel</label>
			<input class="w3-input w3-border" type="text" required></p>
			<p><div class="w3-dropdown-hover">
				    <button class="w3-btn w3-red" id="hide">Semester</button>
				    <div class="w3-dropdown-content w3-border">
				      <a href="#">Link 1</a>
				      <a href="#">Link 2</a>
				      <a href="#">Link 3</a>
				    </div>
				</div></p>
			<p><div class="w3-dropdown-hover">
				    <button class="w3-btn w3-red" id="hide">Mata Kuliah</button>
				    <div class="w3-dropdown-content w3-border">
				      <a href="#">Link 1</a>
				      <a href="#">Link 2</a>
				      <a href="#">Link 3</a>
				    </div>
				</div></p>	
			<p><label class="w3-text-grey">Pilih Artikel</label>
				<input class="" type="file" required>
			</p><br>
  		</form>