<style type="text/css">
	.baru {
		float: right;
		text-decoration: none;
		color: #0067a7;
	}
	.baru:hover {
		text-decoration: underline;
		color: #333333;
	}
</style>
<form class="w3-container w3-card-4"><br>
	<p><label class="w3-text-grey">Nama Grup Foto</label><a class="baru" href="#" id="show" >buat grup foto baru</a><input id="baru" type="text" class="w3-input w3-animate-input" style="width:135px; display: none;" name="">
	<script type="text/javascript">
		$(document).ready(function(){
		    $("#hide").click(function(){
		        $("#baru").hide();
		    });
		    $("#show").click(function(){
		        $("#baru").show();
		    });
		});
	</script>
				<div class="w3-dropdown-hover">
				    <button class="w3-btn w3-red" id="hide">Grup foto yang tersedia</button>
				    <div class="w3-dropdown-content w3-border">
				      <a href="#">Link 1</a>
				      <a href="#">Link 2</a>
				      <a href="#">Link 3</a>
				    </div>
				</div>
			</p>
			<p>
				<label class="w3-text-grey">Pilih Foto</label><input class="" type="file" required></p>
			</p>
			<br>
  		</form>