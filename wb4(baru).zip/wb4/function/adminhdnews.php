<div class="w3-container">
  <h2>Head News</h2>
  <p>Daftar Kiriman Anggota</p>

  <table class="w3-table-all w3-small">
    <tr>
      <th>Name</th>
      <th>Tanggal / Jam</th>
      <th>Kiriman</th>
    </tr>
    <tr>
      <td>Jill</td>
      <td>Smith</td>
      <td>50</td>
    </tr>
    <tr>
      <td>Eve</td>
      <td>Jackson</td>
      <td>94</td>
    </tr>
    <tr>
      <td>Adam</td>
      <td>Johnson</td>
      <td>67</td>
    </tr>
  </table>
</div>