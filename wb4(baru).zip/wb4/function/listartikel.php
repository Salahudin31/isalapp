<?php
function grupartikel(){
	$listartikel = 'daftarartikel.php';
	
	require 'core/import.php';
	
$general->logged_out_protect();

  	$semesters = $semester->get_semester(); 
      foreach ($semesters as $data_semester) {
      	$matkul_semester = $matakuliah->mataKuliah_semester($data_semester['semester']);
	echo "	<div class='panel-group' id='accordion'>
					<div class='panel panel-primary'>
						<div class='panel-heading'>
							<h4 class='panel-title'>
								<a data-toggle='collapse' class='btn-block' data-parent='#accordion' href='#collapse".$data_semester['semester']."'>Semester ".$data_semester['semester']."(".$data_semester['hruf_semester'].")</a>
							</h4>
						</div>
						<div id='collapse".$data_semester['semester']."' class='panel-collapse collapse'>
							<div class='panel-body'>";
foreach ($matkul_semester as $matkul) {
 echo "<div class='w3-col s4 img'><a class='href' href='$listartikel?id=".$matkul['matkul_kd']."'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='100%' class='w3-opacity-min'><div class='display-text'><p>".$matkul['nama_matkul']."</p></div></a></div>";
}
							


						echo "</div>
						</div>
					</div>
				</div> ";
		}

}
?>