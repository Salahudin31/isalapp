<?php
function grupimage(){
	$listimage = 'daftarimage.php';
	require 'core/import.php';

$general->logged_out_protect();
$images = $tbl_image->get_tbl_image();
  foreach ($images as $nama_image) {
    if (isset($nama_image['nama_table']) === "") {
      echo "<div class='w3-row-padding w3-margin-top'>
        <div class='w3-third'>
          <div class='w3-card-4'>
        <a href='././$listimage?nm_tbl=".$nama_image['nama_table']."' ><img src='assets/image/".$nama_image['nama_foto']."' class='w3-hover-grayscale' style='width:100%'></a>
            <div class='w3-container'>
              <h5>5 Terre</h5>
            </div>
          </div>
        </div>";
    }else{}
  }
}
function viewimage(){
	if(isset($_GET['listimage'])){
    $listimage = $_GET['listimage'];

    echo "<iframe src='listimage.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
function viewdetimage(){
	if(isset($_GET['listimage'])){
    $listimage = $_GET['listimage'];

    echo "<iframe src='listdetailimage.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
?>