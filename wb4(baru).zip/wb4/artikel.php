<?php
	include_once 'function/listartikel.php';
?>
  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
  	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-theme.min.css">
  	<link rel="stylesheet" href="assets/bootstrap/css/font-awesome.css">

<div class="w3-container ">
<?php echo grupartikel(); ?> 
				
	 
</div>
	
	<br>
	<br>
	<br>
<style>
	div.w3-container {
		margin-top: 2%;
	}
	div.img {
		padding-left: 7px;
		margin: 3px 0px 7px 0px;

	}
	img:hover {
		opacity: 1;
		box-shadow: 4px 4px 4px 4px #333333;
	}
	div.w3-accordion-content {
		display: inline;
	}
	a.href:hover {
		background-color: unset;
	}
	.display-text {
		position: relative;
		bottom: 20px;
		left: 5%;
		color: #ffffff;
	}
</style>
<script src="assets/jquery/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>