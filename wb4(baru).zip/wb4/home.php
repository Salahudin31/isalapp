  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <link href="assets/w3/font-awesome.min.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
<?php include_once 'function/newshome.php'; ?>
<iframe src="contact.php" width="100%" height="200" ></iframe>
<style>
  h4.title { padding-left: 5%; color: #222222;  }
	iframe {
		border: none;
		margin-bottom: 20px;
	}
  label input {
    float: right;
    margin-right: 1px;
  }
  .user {
    float: left;
  }
  .nama {
    padding-left: 4.5px;
  }
  span {
    float: right;
  }
  .batas {
    margin-top: -5px;
  }
  h3,h5 {
    margin-left: 1%;
  }
  p {
    margin-left: 3%;
    padding: 1%;
    margin-top: 0px;
    margin-bottom: 3%;
    border-left-style: inset;
  }
	a{
		float: right;
		padding-right: 10%;
	}
</style>
<?php
  require 'core/import.php';
  $general->logged_out_protect();



  if (isset($_POST['submit']))
{ 
  $time = date('Y-m-d H:i:s');
  $desc = $_POST['desc_new'];
  $tgl_buat = strtotime($time);
  $id_user = $user->userdata($_SESSION['loginid']);
  
  $news->add_new($desc,$tgl_buat,$id_user);
  header('Location: home.php');
}
?>

<div class='w3-container' style="">
  <form class="w3-container" method="post" action="" style="background-color: #a7c6eb;">
  <label style="margin-top: 3%;">Kiriman</label>
  <textarea class="w3-input w3-animate-input" type="text" name="desc_new" style="width:135px; font-family: Comic Sans MS, cursive, sans-serif;"></textarea><input class="w3-btn" type="submit" name="submit" value="Kirim" style="background-color: #3a73a9;"><br>
</form>
<hr width='100%' size='1'>

<?php
  
  $new = $news->get_news();
  if($new == null){
    echo "<h4 class='title'>Tidak Ada Kiriman</h4>";
  }
  else{
    echo "<h4 class='title'>Kiriman Terbaru</h4>";
  }
  foreach ($new as $news) {
    $users = $user->userdata($news['id_user']);

    echo "<div class='w3-card-4 w3-margin'>
            <div class='w3-container w3-padding-8'>
              
              ";
              if ($news['id_user'] == "0")
                { echo "<a class='user' href=''><img src='./assets/image/salahudin.JPG' class='w3-left w3-circle w3-margin-right' style='width:60px'>
                        <br>
                        <h5 class='nama'>Admin</h5></a>"; 
                }else{
                  echo $users['nama'];
                }
               echo " <br><br><br><span class='w3-opacity'><i>"
               . date('l, j F Y',$news['tgl_buat']) ."</i></span>
            </div>
            <hr class='batas' size='1' width='100%'>
            <div class='w3-container'>
              <p>".$news['desc_new']."</p>
            </div>
          </div>";
  }
?>

</div>
<!--<?php #echo listnew(); ?>