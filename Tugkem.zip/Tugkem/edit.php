<!doctype html>
<html lang="en">
<?php
 
  include_once 'db.php';
  $dbKoneksi = new db('dosen');
  $koneksi = $dbKoneksi->open();

$getnidn=$_GET['nidn'];
$sql="select * from dosen Where nidn='$getnidn'";

$datadosen=$dbKoneksi->recordset($sql,$koneksi);
// and update condition would be as follow ... 

?>
  <head>
    <title>Data Dosen</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css" >
  </head>
  <body>
  <div class="container col">
        <h1>Edit Data Dosen</h1>

        <a href="index.php" class="btn btn-success btn-sm">Kembali</a>
        <form action="../Tugkem/exedit.php" method="POST">
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">NIDN</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="nidn" value="<?php echo $datadosen[0]['nidn']; ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Nama Dosen</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="nama_dosen" placeholder="Nama Mahasiswa">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Gelar</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="gelar" placeholder="Gelar">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Email</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="email" placeholder="Email">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Telepon</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="telp" placeholder="Telepon">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Alamat</label>
            <div class="col-sm-9">
              <textarea class="form-control" name="alamat" placeholder="Alamat"></textarea> 
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-12">
              <input type="submit" class="btn btn-primary btn-lg btn-block" name="update" value="update">
            </div>
          </div>
        </form>  
  </div>
 </body>
</html>