<?php
    include "DB.php";
    $dbKoneksi=new DB();
    $koneksi=$dbKoneksi->open();
    
    $nidn=$_GET['nidn'];
     
    $sql="DELETE FROM dosen where nidn='$nidn'";
    mysqli_query($koneksi,$sql) or die('Gagal ekseskusi SQL :' . $sql );
    header("Location:../Tugkem/index.php");
?>
