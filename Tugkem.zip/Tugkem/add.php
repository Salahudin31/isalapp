<!doctype html>
<html lang="en">
<?php
  include_once 'db.php';

  if(isset($_POST['tambah'])){

    $nidn = $_POST['nidn'];
    $nama_dosen = $_POST['nama_dosen'];
    $gelar = $_POST['gelar'];
    $email = $_POST['email'];
    $telp = $_POST['telp'];
    $alamat = $_POST['alamat'];
  $dbKoneksi = new db('dosen');
  $dbKoneksi->open();
  $dbKoneksi->save(array('nidn'=>$nidn,'nama_dosen'=>$nama_dosen,'gelar'=>$gelar,'email'=>$email,'telp'=>$telp,'alamat'=>$alamat));

}

?>
  <head>
    <title>Data Dosen</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css" >
  </head>
  <body>
  <div class="container col">
        <h1>Tambah Data Dosen</h1>
        <a href="index.php" class="btn btn-success btn-sm">Lihat Data</a>
        <form action="../Tugkem/add.php" method="POST">
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">NIDN</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="nidn" placeholder="NIDN">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Nama Dosen</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="nama_dosen" placeholder="Nama Dosen">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Gelar</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="gelar" placeholder="Gelar">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">email</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="email" placeholder="Email">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Telepon</label>
            <div class="col-sm-9">
              <input type="text" class="form-control" name="telp" placeholder="Telepon">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-3 col-form-label">Alamat</label>
            <div class="col-sm-9">
              <textarea class="form-control" name="alamat" placeholder="Alamat"></textarea> 
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-12">
              <input type="submit" class="btn btn-primary btn-lg btn-block" name="tambah" value="save">
            </div>
          </div>
        </form>  
  </div>
 </body>
</html>