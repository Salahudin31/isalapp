<?php  
	
class db{

	var $server='localhost';
	var $user='root';
	var $pass='';
	var $dbname='Kampus';

	protected $_tableName;
	function __construct($tableName){//konstruktor
		$this->_tableName=$tableName;
	}


	function open(){
		$conn = mysqli_connect($this->server,$this->user,$this->pass,$this->dbname);
		if(!$conn)
			die('Gagal koneksi ke server :' .$this->server);

		return $conn;
	}
	public function close(){
			mysqli_close();
		}
	 function recordset($sql,$koneksi)
    {
        $ret=array();
        $rs=mysqli_query($koneksi,$sql);
        while($rows=mysqli_fetch_assoc($rs)){
            $ret[]=$rows;
        }
        return $ret;
    }
    function save(array $data){
    	$con = $this->open();
		$sql = "INSERT INTO `".$this->_tableName."` SET";
		foreach ($data as $field => $value) {
			$sql .= " `".$field."`='".mysqli_real_escape_string($con,$value)."' ,";
		}
			
		$sql = rtrim($sql, ',');
		$result = mysqli_query($con,$sql);
		if(!$result){
			throw new Exception('Gagal menyimpan data ke table '.$this->_tableName.': '.mysqli_error($con));
				
		}
		if($result){
			echo "<script>alert('Data berhasil di simpan')</script>";
			echo "<script>windows.open('../Tugkem/index.php','_self')</script>";
		}
	}
 public function update($table,$nidn,$nama_dosen,$gelar,$email,$telp,$alamat) { 
  $con = $this->open();
  $res = mysqli_query($con,"UPDATE $table SET nama_dosen='$nama_dosen', gelar='$gelar', email='$email', telp='$telp', alamat='$alamat' WHERE nidn=".$nidn); 
if(!$res){
			throw new Exception('Gagal menyimpan data ke table '.$this->_tableName.': '.mysqli_error($con));
		}
if($res){
header("Location:../Tugkem/index.php");
		}
 }
}


?>