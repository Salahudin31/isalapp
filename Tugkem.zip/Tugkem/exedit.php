<?php 
include_once 'db.php';
  $dbKoneksi = new db('dosen');
  $koneksi = $dbKoneksi->open();
if(isset($_POST['update'])) {
 $table = 'dosen';
 $nama_dosen = $_POST['nama_dosen'];
 $gelar = $_POST['gelar'];
 $email = $_POST['email'];
 $telp = $_POST['telp'];
 $alamat = $_POST['alamat'];
 $nidn= $_POST['nidn'];

 $res=$dbKoneksi->update($table,$nidn,$nama_dosen,$gelar,$email,$telp,$alamat); }
?>