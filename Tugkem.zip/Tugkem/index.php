<?php 
include "db.php";
	
$dbKoneksi=new db('dosen');
//dbkoneksi -> server='192.168.100.2';
$koneksi=$dbKoneksi->open();
$sql="select * from dosen";

$datasiswa=$dbKoneksi->recordset($sql,$koneksi);
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Data Mahasiswa</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css" >

  </head>
  <body>
  <div class="container col">
        <h1>Data Dosen</h1>
        <a href="add.php" class="btn btn-success btn-sm">Tambah Data</a>
        <table class="table table-responsive table-striped table-bordered table-dark text-center">
		  <thead>
		    <tr>
		      <th>NIDN</th>
		      <th>Nama Dosen</th>
        <th>Gelar</th>
		      <th>Email</th>
		      <th>Telpon</th>
		      <th>Alamat</th>
		      <th>Aksi</th>
		    </tr>
		  </thead>
		  <tbody>
		    <?php foreach($datasiswa as $rec):?>
		    <tr>
		      <td><?php echo $rec['nidn'];?></td>
		      <td><?php echo $rec['nama_dosen'];?></td>
        <td><?php echo $rec['gelar'];?></td>
		      <td><?php echo $rec['email'];?></td>
		      <td><?php echo $rec['telp'];?></td>
		      <td><?php echo $rec['alamat'];?></td>
		      <td><a href="edit.php?nidn=<?php echo $rec['nidn'];?>" class="btn btn-primary btn-sm">edit</a>&emsp;<a href="delete.php?nidn=<?php echo $rec['nidn'];?>" class="btn btn-danger btn-sm">delete</a></td>
		    </tr>
		   <?php endforeach;?> 
		  </tbody>
		</table>
  </div>      
  </body>
</html>