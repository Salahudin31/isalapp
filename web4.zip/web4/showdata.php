<?php
include "DB.php";

$dbku = new DB();
//$dbku->server='192.168.100.2';

$koneksi=$dbku->open();
$sql="select * from mahasiswa";

$datamahasiswa = $dbku->recordset($sql,$koneksi);
?>



<!doctype html>
<html lang="en">
  <head>
    <title>Data Mahasiswa</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" >
  </head>
  <body>
  <div class="container">
        <h1>Data Mahasiswa</h1>

        <a href="add.php" class="btn btn-success btn-lg " role="button">Tambah</a>
        <table class="table table-striped table-bordered table-dark">
  <thead>
    <tr>
      <th>NIM</th>
      <th>Nama Mahasiswa</th>
      <th>Email</th>
      <th>Telp</th>
      <th>Alamat</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($datamahasiswa as $rec):?>
    <tr>
      <td><?php echo $rec['nim'];?></td>
      <td><?php echo $rec['nama'];?></td>
      <td><?php echo $rec['email'];?></td>
      <td><?php echo $rec['telp'];?></td>
      <td><?php echo $rec['alamat'];?></td>
      <td>
      		<a href="edit.php?nim=<?php echo $rec['nim'];?>" class="btn btn-primary btn-lg " role="button">Edit</a>
			<a href="hapus.php?nim=<?php echo $rec['nim'];?>" class="btn btn-danger btn-lg " role="button">Hapus</a>
      </td>
    </tr>
   <?php endforeach;?> 
  </tbody>
</table>
</div>
  </body>
</html>