<?php
 
  class DB {

  var $server='localhost';
  var $user='root';
  var $pwd='';
  var $dbname='dbb4';


  function open()
  {
  	 $conn=mysqli_connect($this->server,$this->user,$this->pwd,$this->dbname);
  	 if(!$conn)
  	 	die('Gagal koneksi ke server :'. $this->server);

  	 return $conn;
  }

  function recordset($sql,$koneksi)
  {

  		$res=array();
  		$rs=mysqli_query($koneksi,$sql);

  		while($rows=mysqli_fetch_assoc($rs))
  		{
  			$res[]=$rows;
  		}
  		return $res;
  }

}

?>